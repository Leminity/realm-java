package io.realm.gradle;

object Version {
    const val VERSION = "10.19.0-agp9.1"
}
