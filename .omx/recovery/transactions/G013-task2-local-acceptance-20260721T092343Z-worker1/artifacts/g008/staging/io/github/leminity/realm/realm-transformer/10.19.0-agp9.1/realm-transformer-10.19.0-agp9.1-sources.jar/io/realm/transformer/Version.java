package io.realm.transformer;

public class Version {
    public static final String VERSION = "10.19.0-agp9.1";
    public static final String SYNC_VERSION = "13.26.0";
}
