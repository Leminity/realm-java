package io.realm.processor;

public class Version {
    public static final String VERSION = "10.19.0-agp9.1";
}
